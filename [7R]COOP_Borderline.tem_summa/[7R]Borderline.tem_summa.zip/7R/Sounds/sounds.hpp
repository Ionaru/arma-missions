class akbar {
	name     = "akbar";
	sound[]  = {"7R\Sounds\akbar.ogg", 1, 1, 100};
	titles[] = {};
};

